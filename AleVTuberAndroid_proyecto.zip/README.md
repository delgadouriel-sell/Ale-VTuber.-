# Ale VTuber — proyecto Android inicial

Este proyecto es una primera base nativa para Android 8+ y está configurado para compilar con SDK 36 (Android 16).

## Incluye
- Actividad de configuración.
- Servicio en primer plano con ventana flotante sobre otras aplicaciones.
- Panel arrastrable.
- Alternancia visual entre avatar compacto y cuerpo completo (boceto provisional).
- Síntesis de voz Android en español de México.
- Reconocimiento de voz manual y modo automático con permiso del micrófono.

## Limitaciones de esta primera versión
- El avatar todavía es un boceto con emojis, no un modelo 2D/3D animado.
- El modo automático vuelve a abrir sesiones de reconocimiento de voz; Android/los servicios de voz pueden limitar su continuidad y no escucha el audio interno del juego.
- La voz depende del motor TTS instalado y su paquete de idioma.
- Android 16 puede mostrar avisos y restricciones de micrófono/servicios en segundo plano. El usuario debe activar los permisos manualmente.
- No se incluye APK compilado.

## Compilar
1. Instala Android Studio reciente con Android SDK Platform 36.
2. Descomprime el proyecto y abre la carpeta `AleVTuberAndroid`.
3. Espera la sincronización de Gradle.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. En el teléfono, instala el APK generado y concede permiso de micrófono y "mostrar sobre otras apps".

La primera compilación requiere conexión para descargar Gradle y el plugin de Android.
