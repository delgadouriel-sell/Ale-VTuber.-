package com.alevtuber.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.Locale

class FloatingAleService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var automatic = false
    private var fullBody = false
    private var listening = false
    private lateinit var status: TextView
    private val channel = "ale_vtuber_channel"

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("Ale está contigo").setContentText("Toca la notificación para volver a Ale.")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        else Notification.Builder(this).setContentTitle("Ale está contigo").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(7, notification)
        showPanel()
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "Ale VTuber", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }
    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xEE28143D.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "🐱 Ale ♡"; textSize = 18f; setTextColor(0xFFFFC6F2.toInt()) }
        val hide = Button(this).apply { text = "—"; setOnClickListener { stopSelf() } }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(hide)
        root.addView(header)
        val avatar = TextView(this).apply {
            text = "😺\n♡  ♡"; textSize = 40f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(8, 12, 8, 12)
            setOnClickListener { fullBody = !fullBody; text = if (fullBody) "🐈\n👚\n👗\n👢" else "😺\n♡  ♡" }
        }
        root.addView(avatar)
        status = TextView(this).apply { text = "¡Holaaa! ¿Lista para jugar?"; textSize = 14f; setTextColor(Color.WHITE) }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "🎤 Hablar"; setOnClickListener { speak("¡Aquí estoy! Cuéntame, ¿a qué jugamos?") } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "Escuchar"; setOnClickListener { listenOnce() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        root.addView(Button(this).apply {
            text = "Modo automático: apagado"
            setOnClickListener {
                automatic = !automatic
                text = if (automatic) "Modo automático: encendido" else "Modo automático: apagado"
                if (automatic) listenOnce() else { recognizer?.cancel(); listening = false; status.text = "Modo automático apagado" }
            }
        })
        root.addView(Button(this).apply { text = "Cambiar tamaño: cabeza / cuerpo"; setOnClickListener {
            fullBody = !fullBody; avatar.text = if (fullBody) "🐈\n👚\n👗\n👢" else "😺\n♡  ♡"
        } })
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.72f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 140 }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x=ox+(sx-e.rawX).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(root,lp); return true }
                }; return false
            }
        })
        wm.addView(root, lp); panel = root
    }
    private fun speak(s: String) {
        status.text = s
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "ale_reply")
    }
    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "El reconocimiento de voz no está disponible en este teléfono."; return }
        if (listening) return
        listening = true
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { status.text = "Te escucho… 🎧" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                listening = false
                status.text = "No te escuché. Pulsa Escuchar para intentar de nuevo."
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                status.text = if (said.isBlank()) "No alcancé a escucharte." else "Dijiste: $said"
                if (said.isNotBlank()) speak("¡Te escuché! $said. ¡Vamos con todo!")
                if (automatic) status.postDelayed({ if (automatic) listenOnce() }, 1800)
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("es", "MX")
    }
    override fun onDestroy() {
        automatic = false; recognizer?.destroy(); tts?.stop(); tts?.shutdown()
        if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
