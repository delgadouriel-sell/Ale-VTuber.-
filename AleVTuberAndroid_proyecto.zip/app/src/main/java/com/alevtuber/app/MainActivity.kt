package com.alevtuber.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(36), dp(22), dp(22))
            setBackgroundColor(0xFF190D2B.toInt())
        }
        fun label(s: String, size: Float, color: Int) = TextView(this).apply {
            text = s; textSize = size; setTextColor(color); setPadding(0, dp(10), 0, dp(10))
        }
        root.addView(label("🐱 Ale VTuber", 30f, 0xFFFFC6F2.toInt()))
        root.addView(label("Tu compañera gamer • versión inicial", 16f, -1))
        root.addView(label("Activa la ventana flotante y concede permiso de micrófono para hablar con Ale. El modo automático escucha solo mientras esté activado.", 15f, 0xFFE7D9F5.toInt()))
        val start = Button(this).apply { text = "Mostrar a Ale"; setOnClickListener { startAle() } }
        root.addView(start)
        val help = Button(this).apply { text = "Cómo activar la ventana flotante"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this@MainActivity, "Permiso de ventana flotante activado", Toast.LENGTH_SHORT).show()
        } }
        root.addView(help)
        root.addView(Button(this).apply { text = "Cerrar Ale"; setOnClickListener { stopService(Intent(this@MainActivity, FloatingAleService::class.java)) } })
        root.addView(label("Nota: esta es una base funcional. La voz usa los servicios de reconocimiento y síntesis disponibles en Android; no analiza el audio interno del juego.", 13f, 0xFFBCA9D2.toInt()))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
    }
    private fun startAle() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Activa 'Permitir mostrar sobre otras apps' y vuelve a tocar Mostrar a Ale.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 23); return
        }
        val i = Intent(this, FloatingAleService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 23 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startAle()
    }
}
